
public class Main {
    public static void main(String[] args) {
        Sale s1 = new Sale(new Customer("Alice", "Gold"), "21/02/2024");

        s1.setServiceExpense(1000);
        s1.setProductExpense(500);

        s1.displayInfo();
    }
}