public class Sale {
        private Customer customer;
        private String date;
        private double serviceExpense;
        private double productExpense;

        public Sale(Customer customer, String date) {
            this.customer = customer;
            this.date = date;
        }
        public double getServiceExpense() {
            return serviceExpense;
        }

        public double getProductExpense() {
            return productExpense;
        }

        public double getTotalExpense() {
            return serviceExpense + productExpense;
        }

        public void setServiceExpense(double serviceExpense) {
            this.serviceExpense = serviceExpense;
        }

        public void setProductExpense(double productExpense) {
            this.productExpense = productExpense;
        }

        // Method to display the sale information
        public void displayInfo() {
            System.out.println("Customer Name: " + customer.getName());
            System.out.println("Customer Type: " + customer.getType());
            System.out.println("Date: " + date);

            double serviceDiscount = serviceExpense * customer.getServiceMemberDiscount();
            double productDiscount = productExpense * customer.getProductMemberDiscount();

            System.out.println("Service Expense: $" + serviceExpense);
            System.out.println("Service Discount: $" + serviceDiscount);
            System.out.println("Service Expense After Discount: $" + (serviceExpense - serviceDiscount));
            System.out.println("Product Expense: $" + productExpense);
            System.out.println("Product Discount: $" + productDiscount);
            System.out.println("Product Expense After Discount: $" + (productExpense - productDiscount));

            System.out.println("Total Expense: $" + getTotalExpense());
            System.out.println("Total Discount: $" + (serviceDiscount + productDiscount));
            System.out.println("Total Expense After Discount: $" + (getTotalExpense() - serviceDiscount - productDiscount));
        }
}
